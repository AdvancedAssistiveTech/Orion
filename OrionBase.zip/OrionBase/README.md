# Orion
Used for the development of Orion retail assistant, an Eclipse based sales solution

Orion is still under heavy development, but is stable and equipped with basic retail management functions. 1.0 is almost here!

List of functions (Very basic descriptions, read the unabridged version in the wiki!):

#### (Sale-totaller)
##### (complete!)

- A function that takes an input code, matches it to current registered inventory and loops, totaling the sale  
